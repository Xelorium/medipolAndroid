package com.medipol.medipolsms;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactViewHolder> {

    List<ContactModel> contactModelList = new ArrayList<>();

    public ContactAdapter(List<ContactModel> contactModels) {
        this.contactModelList = contactModels;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View view = inflater.inflate(R.layout.contact_item, parent, false);

        ContactViewHolder contactViewHolder = new ContactViewHolder(view);

        return contactViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ContactViewHolder holder, final int position) {

        holder.tvNumber.setText(contactModelList.get(position).number);
        holder.tvName.setText(contactModelList.get(position).name);
        holder.cb.setChecked(contactModelList.get(position).isChecked);

        holder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                contactModelList.get(position).isChecked = !contactModelList.get(position).isChecked;

                holder.cb.setChecked(contactModelList.get(position).isChecked);
            }
        });


    }

    @Override
    public int getItemCount() {
        return contactModelList.size();
    }


    public void sendSms(Context context) {


        List<String> numbers = new ArrayList<>();

        for (int i = 0; i < contactModelList.size(); i++) {
            if (contactModelList.get(i).isChecked) {
                numbers.add(contactModelList.get(i).number);
            }
        }

        Bundle bundle = new Bundle();
        bundle.putSerializable("number", (Serializable) numbers);

        Intent intent = new Intent(context, SmsAct.class);
        intent.putExtras(bundle);
        context.startActivity(intent);

    }

}




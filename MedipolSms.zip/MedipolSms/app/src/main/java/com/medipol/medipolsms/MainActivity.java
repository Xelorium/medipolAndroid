package com.medipol.medipolsms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnGrup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {

                    //ilk defa izin soruyor

                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[] {Manifest.permission.READ_CONTACTS}, 1);


                } else {
                    //izin önceden alınmış
                    Log.e("Request", "test");
                    readContact();
                }


            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1:
                //contact okuma pop up
                readContact();
                break;
        }

    }
    public void readContact() {
        //key -> value
        //0101 -->ali
        //0202 -->burak
        HashMap<String, String> hashMap = new HashMap<>();

        Cursor phones = this.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        while (phones.moveToNext())
        {
            String name=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            phoneNumber = phoneNumber.replaceAll("\\s+","");
            hashMap.put(phoneNumber, name);
        }
        phones.close();

        List<ContactModel> contactList = new ArrayList<>();

        for (Map.Entry<String, String> entry: hashMap.entrySet()) {
            String number = entry.getKey();
            String name = entry.getValue();

            contactList.add(new ContactModel(name, number, false));

        }

        Bundle bundle = new Bundle();
        bundle.putSerializable("contact", (Serializable) contactList);

        Intent intent = new Intent(MainActivity.this, ContactAct.class);
        intent.putExtras(bundle);
        startActivity(intent);


    }
}

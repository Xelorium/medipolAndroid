package com.medipol.medipolsms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.security.Permission;
import java.util.ArrayList;
import java.util.List;

public class SmsAct extends AppCompatActivity {

    private List<String> numbers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Bundle bundle = getIntent().getExtras();
        numbers = (List<String>) bundle.getSerializable("number");

        findViewById(R.id.btnGonder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(SmsAct.this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                    ActivityCompat.requestPermissions(SmsAct.this,
                            new String[] {Manifest.permission.SEND_SMS}, 42);

                } else {
                    sendSms();
                }

            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 42:
                //izin alındı
                sendSms();
                break;
        }
    }

    public void sendSms() {

        String msg = ((EditText) findViewById(R.id.etSms)).getText().toString();

        SmsManager manager = SmsManager.getDefault();

        for (int i = 0; i < numbers.size(); i++) {
            //sms

            ArrayList<String> part = manager.divideMessage(msg);
            manager.sendMultipartTextMessage(numbers.get(i), null, part, null, null);

        }
        Toast.makeText(SmsAct.this, "Sms gönderildi", Toast.LENGTH_SHORT).show();
    }
}

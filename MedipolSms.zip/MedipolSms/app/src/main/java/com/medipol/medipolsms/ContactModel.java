package com.medipol.medipolsms;

import java.io.Serializable;

public class ContactModel implements Serializable {

    public String name;
    public String number;
    public boolean isChecked;

    public ContactModel(String name, String number, boolean isChecked) {
        this.name = name;
        this.number = number;
        this.isChecked = isChecked;
    }

}

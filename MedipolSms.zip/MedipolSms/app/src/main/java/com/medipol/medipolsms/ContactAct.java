package com.medipol.medipolsms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import java.util.Comparator;
import java.util.List;

public class ContactAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        Bundle bundle = getIntent().getExtras();

        List<ContactModel> contactModelList = (List<ContactModel>) bundle.getSerializable("contact");

        //sort
        contactModelList.sort(new Comparator<ContactModel>() {
            @Override
            public int compare(ContactModel o1, ContactModel o2) {
                return o1.name.compareTo(o2.name);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.rc);

        final ContactAdapter adapter = new ContactAdapter(contactModelList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);

        findViewById(R.id.btnKaydet).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.sendSms(ContactAct.this);
            }
        });


    }
}

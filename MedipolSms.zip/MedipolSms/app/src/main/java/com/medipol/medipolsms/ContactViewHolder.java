package com.medipol.medipolsms;

import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ContactViewHolder extends RecyclerView.ViewHolder {

    public TextView tvName;
    public TextView tvNumber;
    public CheckBox cb;

    public ContactViewHolder(@NonNull View itemView) {
        super(itemView);

        tvName = itemView.findViewById(R.id.tvName);
        tvNumber = itemView.findViewById(R.id.tvNumber);
        cb = itemView.findViewById(R.id.cbContact);

    }

    public void setOnClickListener(View.OnClickListener listener) {
        itemView.setOnClickListener(listener);
    }
}
